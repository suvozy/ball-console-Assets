//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _GLDEMOAPP_H_
#define _GLDEMOAPP_H_

HWND GetMainHWND();
HDC GetMainHDC();

#endif