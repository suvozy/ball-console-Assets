//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//
//The code in this file was taken from someone elses open source project, I dont remember where I found it,
//if you know who this belongs to feel free to contact me so I can give them appropriate credit.
//
#pragma once
#ifndef _FREETYPE_UTILS_H_
#define _FREETYPE_UTILS_H_

#include <ft2build.h>
#include <freetype/freetype.h>
#include <freetype/ftglyph.h>
#include <freetype/ftoutln.h>
#include <freetype/fttrigon.h>
#include <windows.h>
#include <gl/glew.h>
#include <gl/GLU.h>
#include <string>
#include "mytypes.h"

struct sSizei;

namespace FreetypeUtils 
{
	//Creates an opengl display list for this font type.
	void CreateDisplayList(FT_Face ftFace, char ch, GLuint uiListBase, GLuint* uiTexBase, uint32* puiMaxPixelWidth, uint32* puiMaxPixelHeight, sSizei* pSizes);

	void InitializeFont(const std::string& strFontName, uint32 uiFontHeight, uint32** uiFontTextureIds, uint32* uiListIds, uint32* puiMaxPixelWidth, uint32* puiMaxPixelHeight, sSizei* pSizes);
};

#endif