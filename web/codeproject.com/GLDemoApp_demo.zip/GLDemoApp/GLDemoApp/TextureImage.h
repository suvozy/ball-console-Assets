//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#pragma once
#ifndef _TEXTURE_IMAGE_H_
#define _TEXTURE_IMAGE_H_

#include "mytypes.h"

class CTextureImage
{
public:
	friend class CTextureLoader;
	enum PIXEL_FORMAT {PX_RGB, PX_RGBA};

public:
	uint32 m_uiWidth;
	uint32 m_uiHeight;
	uint32 m_uiBitDepth;
	uint32 m_uiBytesPerPixel;

	bool   m_bAlphaChannel;

	ubyte* m_pImageBuffer;
	uint32 m_uiBufferSize;

	PIXEL_FORMAT m_pxFormat;
	
	uint32 m_uiHardwareId;
	uint32 m_uiReferenceCount;
	std::string m_strLocation;
public:
	CTextureImage();
	~CTextureImage();

	// Creates an image.
	//
	void CreateImage(uint32 uiWidth, uint32 uiHeight, uint32 uiBitDepth, bool bAlphaChannel, ubyte* pImageBuffer = NULL);

	//Replaces internal image buffer pointer with the provided pointer.
	void SetImageBuffer(ubyte* pImageBuffer, bool bAllocate = false, uint32 uiImageBufferSize = 0);

	// Retrieves the pixel from the image as an unsigned integer.
	// keep in mind that the pixel values may be less then 4 bytes.
	//
	uint32 GetPixelInt(uint32 uiX, uint32 uiY);

	//
	//
	ubyte* GetPixelByteP(uint32 uiX, uint32 uiY);

	//
	inline void SetWidth(uint32 uiWidth)				  { m_uiWidth = uiWidth; }
	inline void SetHeight(uint32 uiHeight)			      { m_uiHeight = uiHeight; }
	inline void SetBitDepth(uint32 uiBitDepth)		      { m_uiBitDepth = uiBitDepth; }
	inline void SetHasAlphaChannel(bool bAlphaChannel)  { m_bAlphaChannel = bAlphaChannel; }
	inline void SetPixelFormat(PIXEL_FORMAT pxFormat)   { m_pxFormat = pxFormat; } 

	inline uint32 GetWidth()			 { return m_uiWidth; }
	inline uint32 GetHeight()			 { return m_uiHeight; }
	inline uint32 GetBitDepth()		     { return m_uiBitDepth; }
	inline bool   HasAlphaChannel()	     { return m_bAlphaChannel; }
	inline ubyte* GetImageBuffer() 	     { return m_pImageBuffer; }
	inline uint32 GetBytesPerPixel()     { return m_uiBytesPerPixel; }
	inline PIXEL_FORMAT GetPixelFormat() { return m_pxFormat; }

	inline bool IsValidCoordinates(uint32 uiX, uint32 uiY) 
	{ 
		return ((uiX >= 0 && uiX <= m_uiWidth) && (uiY >= 0 && uiY <= m_uiHeight));
	}
};

#endif