//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "demo.h"
#include "render.h"
#include "ColladaLoader.h"

sMesh* g_pTestColladaMesh = NULL;
uint32 g_uiTextureId = 0;

//Do all your init stuff here.
//
void InitDemo()
{
	RenderInit();

	CColladaLoader loader;
	g_pTestColladaMesh = loader.LoadColladaFile(BuildResourcePath("test.dae"));

	g_uiTextureId = RenderLoadTexture(BuildResourcePath("test.tga"));
}

//Main Loop
//
bool RunDemo()
{
	static float32 fRotation = 0.0f;
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();

		gluLookAt(0.0f, 0.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
		
		RenderGroundGrid(-4.0f);
		
		glPushMatrix();
			glRotatef(fRotation, 1.0f, 1.0f, 1.0f);
			RenderMesh(*g_pTestColladaMesh);
		glPopMatrix();

		glPushMatrix();
			glPointSize(10.0f);
			glBegin(GL_POINTS);
				glColor3f(1.0f, 1.0f, 1.0f);
				glVertex3f(0.0f, 0.0f, 0.0f);
			glEnd();
		glPopMatrix();

	glPopMatrix();
	
	RenderText(&g_defaultFont, "F1 : Fullscreen", Vector2f(0.0f, 20.0f));
	RenderText(&g_defaultFont, "F2 : Windowed", Vector2f(0.0f, 40.0f));


	RenderBegin2dMode();
		
		RenderTexture(Vector2f(RenderGetOrthoWidth() * .5f, 50.0f), g_uiTextureId, 0.0f);

	RenderEnd2dMode();

	if(GetAsyncKeyState(VK_F1))
	{
		sRenderResolution sRes;
		sRes.nWidth = RenderGetDesiredWidth();
		sRes.nHeight = RenderGetDesiredHeight();
		sRes.nBitDepth = RenderGetBitDepth();

		RenderSetResolution(sRes, true);
	}else if(GetAsyncKeyState(VK_F2))
	{
		sRenderResolution sRes;
		sRes.nWidth = RenderGetDesiredWidth();
		sRes.nHeight = RenderGetDesiredHeight();
		sRes.nBitDepth = RenderGetBitDepth();

		RenderSetResolution(sRes, false);
	}

	fRotation += .1f;
	if(fRotation > 360.0f)
		fRotation = 0.0f;

	RenderStats();
	RenderSwapBuffers();

	return (GetAsyncKeyState(VK_ESCAPE) & 0xFFFF) ? false : true;
}

//Release resources.
//
void EndDemo()
{
	RenderReleaseTexture(g_uiTextureId);
	RenderReleaseMesh(&g_pTestColladaMesh);
	RenderDestroy();
}
