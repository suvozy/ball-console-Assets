//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _TEXTURE_H_
#define _TEXTURE_H_
#include "mytypes.h"

class CTextureImage;

CTextureImage* LoadImageFromDisk(const std::string& strFileName);
CTextureImage* LoadTGAFromDisk(const std::string& strFileName);
CTextureImage* LoadTGA(ubyte* pImageData, uint32 uiBufferSize);

#endif