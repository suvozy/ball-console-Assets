//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "utils.h"
#include "render.h"
#pragma warning(disable:4267)

std::string g_strResourceDirectory = "..\\Resources";

std::string BuildLocalPathTo(const std::string& strFileName)
{
	CHAR lpDirectory[MAX_PATH] = {0,};
	GetCurrentDirectory(1024, lpDirectory);

	return std::string(std::string(lpDirectory) + "\\" + strFileName);
}

std::string BuildResourcePath(const std::string& strFileName)
{
	return std::string(g_strResourceDirectory + "\\" + strFileName);
}

std::string BuildSoundResourcePath(const std::string& strSoundFileName)
{
	return std::string(g_strResourceDirectory + "\\soundfx\\" + strSoundFileName);
}

std::string BuildMusicResourcePath(const std::string& strSongFileName)
{
	return std::string(g_strResourceDirectory + "\\music\\" + strSongFileName);
}

std::string BuildShaderResourcePath(const std::string& strShaderFileName)
{
	return std::string(g_strResourceDirectory + "\\shaders\\" + strShaderFileName);
}

std::string MakeURI(const std::string strFilePath)
{
	std::string strNewURI = strFilePath;
	for(uint32 uiCurrChar = 0; uiCurrChar < strFilePath.length(); uiCurrChar++)
	{
		if(strNewURI[uiCurrChar] == '\\')
		{
			strNewURI[uiCurrChar] = '/';
		}
	}

	//Figure out if this is a drive letter
	//if so, prefix '/'
	//need a better way to figure out driver letter, must move that coder here from my other lib.
	//for now this works...
	if(strNewURI[1] == ':')
	{
		strNewURI.insert(0, "/");
	}

	strNewURI.insert(0, "file://");

	return strNewURI;
}

std::string ReadTextFileToBufffer(const std::string& strFileName)
{
	FILE *fp;
	char *content = NULL;

	int count=0;

	if (strFileName.size()) 
	{
		fp = fopen(strFileName.c_str(),"rt");

		if (fp != NULL) 
		{
			fseek(fp, 0, SEEK_END);
			count = ftell(fp);
			rewind(fp);

			if (count > 0) {
				content = (char *)malloc(sizeof(char) * (count+1));
				count = fread(content,sizeof(char),count,fp);
				content[count] = '\0';
			}
			fclose(fp);
		}
	}

	std::string strContent = content;

	if(content)
		free(content);

	return strContent;
}
