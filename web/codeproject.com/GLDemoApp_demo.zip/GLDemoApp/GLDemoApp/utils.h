//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _UTILS_H_
#define _UTILS_H_

struct sSizei 
{
	uint32 uiWidth;
	uint32 uiHeight;

	void Scale(uint32 uiScale) { uiWidth *= uiScale; uiHeight *= uiScale; }
	void GrowBy(uint32 uiAmt) { uiWidth += uiAmt; uiHeight += uiAmt; }
};


inline int NextP2(int iNext)
{
	int iRVal = 1;
	// rval<<=1 Is A Prettier Way Of Writing rval*=2; 
	while(iRVal < iNext) iRVal<<=1;
	return iRVal;
}

std::string BuildLocalPathTo(const std::string& strFileName);
std::string BuildResourcePath(const std::string& strFileName);
std::string BuildSoundResourcePath(const std::string& strSoundFileName);
std::string BuildMusicResourcePath(const std::string& strSongFileName);
std::string BuildShaderResourcePath(const std::string& strShaderFileName);
std::string MakeURI(const std::string strFilePath);

class CTextureImage;

std::string ReadTextFileToBufffer(const std::string& strFileName);
#endif