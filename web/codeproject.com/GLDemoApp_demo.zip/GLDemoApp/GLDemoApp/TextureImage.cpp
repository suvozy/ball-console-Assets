//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//
#include "stdafx.h"
#include "TextureImage.h"

CTextureImage::CTextureImage() : m_uiWidth(0), m_uiHeight(0), m_uiBitDepth(0),
m_bAlphaChannel(false), m_pImageBuffer(0), m_uiHardwareId(0), m_uiReferenceCount(0)
{

}

CTextureImage::~CTextureImage()
{
	delete m_pImageBuffer;
}

void CTextureImage::CreateImage(uint32 uiWidth, uint32 uiHeight, uint32 uiBitDepth, bool bAlphaChannel, ubyte* pImageBuffer)
{
	m_uiWidth = uiWidth;
	m_uiHeight = uiHeight;
	m_uiBitDepth = uiBitDepth;
	m_bAlphaChannel = bAlphaChannel;

	m_uiBufferSize = uiWidth * uiHeight * uiBitDepth;
	m_pImageBuffer = new ubyte[m_uiBufferSize];
	
	if(pImageBuffer)
		memcpy(m_pImageBuffer, pImageBuffer, sizeof(ubyte) * m_uiBufferSize);
}

void CTextureImage::SetImageBuffer(ubyte* pImageBuffer, bool bAllocate, uint32 uiImageBufferSize) 	 
{
	if(m_pImageBuffer)
		delete m_pImageBuffer;

	if(bAllocate)
	{
		if(uiImageBufferSize == 0)
			uiImageBufferSize = m_uiWidth * m_uiHeight * m_uiBytesPerPixel;

		m_pImageBuffer = new ubyte[uiImageBufferSize];

		memcpy(m_pImageBuffer, pImageBuffer, uiImageBufferSize);
	}else
		m_pImageBuffer = pImageBuffer;
}

uint32 CTextureImage::GetPixelInt(uint32 uiX, uint32 uiY)
{
	uint32 uiPixelValue = 0;

	if(m_pImageBuffer && IsValidCoordinates(uiX, uiY))
	{
		uiPixelValue = *(reinterpret_cast<uint32*>(GetPixelByteP(uiX, uiY)));
	}

	return uiPixelValue;
}

ubyte* CTextureImage::GetPixelByteP(uint32 uiX, uint32 uiY)
{
	ubyte* pPixel = 0;
	if(m_pImageBuffer && IsValidCoordinates(uiX, uiY))
	{
		uint32 uiRowSize = m_uiWidth * m_uiBytesPerPixel;
		uint32 uiColumnOffset = uiX * m_uiBytesPerPixel;

		pPixel = &(m_pImageBuffer[((uiY * uiRowSize) + uiColumnOffset)]);	
	}

	return pPixel;
}

