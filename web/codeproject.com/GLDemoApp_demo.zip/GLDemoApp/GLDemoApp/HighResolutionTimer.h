// This class was taken from one originally written by Syrus Mesdaghi
// Modifications by Kristian-Angel Carazo free to use and distribute as you see fit.
//
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//
#ifndef HIGH_RESOLUTION_TIMER_H
#define HIGH_RESOLUTION_TIMER_H

class  CHighResolutionTimer  
{
public:
	
	//singleton instance
	static	CHighResolutionTimer *instance;
	

	CHighResolutionTimer();
	virtual ~CHighResolutionTimer();
	
	// returns a high resolution elapsed time 
	float64 getElapsedTimeInSeconds();	

	float64 getRealDifference() { return elapsedTime - lastElapsedTime; }
	float32 getDifference();

	//resets the timer
	void reset();	


	float32 m_fScale;
private:

	LARGE_INTEGER	counterStart,
					counterEnd;

	unsigned long frequency;

	float64	elapsedTime,
			lastElapsedTime,
			frequencyInverse;
};

#endif
