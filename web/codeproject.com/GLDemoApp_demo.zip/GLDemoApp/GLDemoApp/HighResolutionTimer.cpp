//TODO: verify that roll over is handled properly.
//TODO: this class should not be a singleton ;)
#include "stdafx.h"
#include "HighResolutionTimer.h"
#include <iostream>
#include <windows.h>

CHighResolutionTimer *CHighResolutionTimer::instance = NULL;
static const float32 MAX_TIME_THRESHHOLD = .01f;

CHighResolutionTimer::CHighResolutionTimer() : m_fScale(1.0f) {

	
	if (instance != NULL){
		std::cout << "====>>> CRITICAL: CHighResolutionTimer() is a singleton but second instance was made <<<====" << std::endl;
	}
	
	instance = this;
	
	counterStart.QuadPart = 0;
	counterEnd.QuadPart = 0;

	elapsedTime = 0;
	lastElapsedTime = 0;
	frequencyInverse = 0;
	frequency = 0;


	QueryPerformanceFrequency((LARGE_INTEGER*)&frequency);
	
	if (frequency == 0){
		std::cout << "====> System does NOT support high-res performance counter <====" << std::endl;
	}else{			
		frequencyInverse = 1.0/frequency;
		std::cout << "System counter  frequency: " << frequency << "   frequencyInverse: " << frequencyInverse << std::endl;
		reset();
	}
}

CHighResolutionTimer::~CHighResolutionTimer()
{	
	std::cout << "CHighResolutionTimer::~CHighResolutionTimer()" << std::endl;
}


void CHighResolutionTimer::reset(){
	QueryPerformanceCounter(&counterStart);
	lastElapsedTime = 0;
}

double CHighResolutionTimer::getElapsedTimeInSeconds(){
	
	QueryPerformanceCounter(&counterEnd);
	lastElapsedTime = elapsedTime;	
	
	//-------------------------  COUNTER ROLL OVER ------------------------------
	// TO CHECK: check to see what the max QueryPerformanceCounter() can return. is it 63 or 64 bit. since msdn
	//           defines (counterStart).QuadPart as LONGLONG which is signed 64 bit int, i have assumed the max
	//           the function can return is 63 bit. if assumpsion is not correct then we should use 0xFFFFFFFFFFFFFFFF 
	//           instead of 0x7FFFFFFFFFFFFFFF

	// if roll over, set counterStart to be the proper off set from counter end so elapsed time works out fine
	if (counterStart.QuadPart > counterEnd.QuadPart){


		// 0x7FFFFFFFFFFFFFFF is 9223372036854775809
		// -(destination - source)
		(counterStart).QuadPart = -(0x7FFFFFFFFFFFFFFF - (counterStart).QuadPart);
															
		//--------- DEBUG -------------
		double newElapsedtime = (((counterEnd).QuadPart - (counterStart).QuadPart) * frequencyInverse);
		std::cout << "======>>>> lastElapsedTime: " << lastElapsedTime << std::endl;
		std::cout << "======>>>> newElapsedTime: " <<  newElapsedtime<< std::endl;

		#pragma warning(disable:4996)
		char buffer[512];
		sprintf(&buffer[0], "CRITICAL WARNING: lastElapsedTime > elapsedTime, counter roll over detected.\n adjustment was made to compensate. verify the following values!\n lastElapsedTime: %g\n newElapsedtime: %g", lastElapsedTime, newElapsedtime);
		MessageBoxA(NULL, &buffer[0], "CHighResolutionTimer", MB_OK|MB_ICONINFORMATION);
	}
	//---------------------------------------------------------------------------


	elapsedTime	= ((counterEnd).QuadPart - (counterStart).QuadPart) * frequencyInverse;			

	//elapsedTime = GetTickCount() / 1000.0f;
	return elapsedTime;
}	


float32 CHighResolutionTimer::getDifference() { 
 return (static_cast<float32>(elapsedTime - lastElapsedTime)) * m_fScale; 
}
