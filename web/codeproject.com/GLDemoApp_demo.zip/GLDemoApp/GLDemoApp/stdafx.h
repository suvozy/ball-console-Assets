//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _STDAFX_H_
#define _STDAFX_H_

#include "mytypes.h"
#include <windows.h>
#include <string>
#include "utils.h"
#include "gldemoapp.h"
#include "texture.h"

#endif
