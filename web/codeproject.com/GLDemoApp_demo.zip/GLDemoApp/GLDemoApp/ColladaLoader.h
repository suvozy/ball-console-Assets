//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _COLLADA_LOADER_H_
#define _COLLADA_LOADER_H_
#include <string>
#include <dae.h>
#include <dom/domCOLLADA.h>
#include <dom/domConstants.h>
#include <dom/domProfile_COMMON.h>

struct sMesh;
struct sMaterial;

struct sColladaMeshLoadData
{
	uint32* pIdxArray;
	uint32  uiIndexCount;
	uint32  uiInputCount;

	uint32 nPositionOffset;
	uint32 nNormalOffset;
	uint32 nTexOffset;
	uint32 nColorOffset;

	float32* pfVertices;
	float32* pfNormals;
	float32* pfTexCoords;
	float32* pfColors;

	uint32 nVertexCount;
	uint32 nNormalCount;
	uint32 nTexCoordCount;
	uint32 nColorCount;

	uint32 nVertexComponentCount;
	uint32 nNormalComponentCount;
	uint32 nTexCoordComponentCount;
	uint32 nColorComponentCount;
};

class CColladaLoader
{
	void LoadBlinn(domProfile_COMMON* pProfile, domProfile_COMMON::domTechnique::domBlinn* pBlinn, sMaterial* pMaterial);
	void LoadLambert(domProfile_COMMON* pProfile, domProfile_COMMON::domTechnique::domLambert* pLambert, sMaterial* pMaterial);

	sMaterial* LoadMaterial(domMaterial* pMaterial);

	void LoadVertices(sColladaMeshLoadData& colladaMesh, domInputLocalOffset* pCurrentOffset);

	void LoadNormals(sColladaMeshLoadData& colladaMesh, domInputLocalOffset* pCurrentOffset);
	void LoadNormals(sColladaMeshLoadData& colladaMesh, domInputLocal* pCurrent);
	void LoadNormals(sColladaMeshLoadData& colladaMesh, domElement* pCurrentElement);

	void LoadTextureCoords(sColladaMeshLoadData& colladaMesh, domInputLocalOffset* pCurrentOffset);
	void LoadTextureCoords(sColladaMeshLoadData& colladaMesh, domInputLocal* pCurrent);
	void LoadTextureCoords(sColladaMeshLoadData& colladaMesh, domElement* pElement);
	
	void LoadColors(sColladaMeshLoadData& colladaMesh, domInputLocalOffset* pCurrentOffset);
	void LoadColors(sColladaMeshLoadData& colladaMesh, domInputLocal* pCurrent);
	void LoadColors(sColladaMeshLoadData& colladaMesh, domElement* pElement);

	void ConvertColladaMeshData(sColladaMeshLoadData& colladaMesh, sMesh* pMesh);

public:
	CColladaLoader(void);
	~CColladaLoader(void);
	
	sMesh* LoadColladaFile(const std::string& strFilePath);
};

#endif