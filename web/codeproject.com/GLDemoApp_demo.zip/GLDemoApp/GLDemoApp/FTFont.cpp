//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "ftfont.h"
#include "FreetypeUtils.h"

CFTFont::CFTFont(void) : m_glTextureIds(NULL), m_uiMaxPixelHeight(0), m_uiMaxPixelWidth(0)
{
	memset(&m_ftSizes, 0, sizeof(m_ftSizes));
}

CFTFont::~CFTFont(void)
{
}

void CFTFont::Init(const std::string& strFileName, unsigned int uiHeight)
{
	m_uiFontHeight = uiHeight;
	FreetypeUtils::InitializeFont(strFileName, uiHeight, &m_glTextureIds, &m_uiBase, &m_uiMaxPixelWidth, &m_uiMaxPixelHeight, m_ftSizes);
}

void CFTFont::Clean()
{
	glDeleteLists(m_uiBase,128);
	glDeleteTextures(128, m_glTextureIds);
	delete [] m_glTextureIds;
}

uint32 CFTFont::CalcTextWidth(const std::string& strText)
{
	uint32 uiPixelLength = 0;
	for(uint32 i = 0; i < strText.size(); i++)
	{
		uiPixelLength += m_ftSizes[static_cast<uint32>(strText[i])].uiWidth;
	}

	return uiPixelLength;
}

uint32 CFTFont::CalcTextHeight(const std::string& strText)
{
	return m_uiMaxPixelHeight;
}

void CFTFont::CalcExtents(const std::string& strText, uint32& uiWidth, uint32& uiHeight)
{
	uiWidth = CalcTextWidth(strText);
	uiHeight = CalcTextHeight(strText);
}