//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "texture.h"
#include "ImageFileHeaders.h"
#include "TextureImage.h"
#pragma warning(disable:4996)

CTextureImage* LoadImageFromDisk(const std::string& strFileName)
{
	return LoadTGAFromDisk(strFileName);
}

CTextureImage* LoadTGAFromDisk(const std::string& strFileName)
{
	FILE* pFile = fopen(strFileName.c_str(), "rb");
	CTextureImage* pImage = NULL;

	if(pFile)
	{
		ubyte* pImageData = NULL;
		uint32 uiBufferSize = 0;

		int32 nFileNumber = _fileno(pFile);
		uiBufferSize = _filelength(nFileNumber);		//		fseek(pFile, 0, SEEK_END);	 uiBufferSize = ftell(pFile);

		pImageData = new ubyte[uiBufferSize];

		fread(pImageData, sizeof(ubyte), uiBufferSize, pFile);

		fclose(pFile);

		pImage = LoadTGA(pImageData, uiBufferSize);

		delete pImageData;
	}

	pImage->m_strLocation = strFileName;
	return pImage;
}

CTextureImage* LoadTGA(ubyte* pImageData, uint32 uiBufferSize)
{
	IFH_TGAHeader*	pIfhTGA;

	pIfhTGA = reinterpret_cast<IFH_TGAHeader*>(pImageData);

	const uint32 uiImageType			= pIfhTGA->ImgType;
	const uint32 uiImageWidth			= pIfhTGA->WidthLo + pIfhTGA->WidthHi * 256;
	const uint32 uiImageHeight			= pIfhTGA->HeightLo + pIfhTGA->HeightHi * 256;
	const uint32 uiImageBytesPerPixel	= pIfhTGA->Bpp / 8;
	const uint32 uiImageSize			= uiImageWidth * uiImageHeight * uiImageBytesPerPixel;
	const uint32 uiImageIdent			= pIfhTGA->ImgIdent;

	//Validate supported format.
	if( ( uiImageType != 2 /*&& uiImageType != 10*/ ) ||
		( uiImageWidth == 0 ) || ( uiImageHeight == 0 ) ||
		( uiImageBytesPerPixel != 3 && uiImageBytesPerPixel != 4 ) )
	{
		return NULL;
	}

	CTextureImage*  pImage = new CTextureImage;

	pImage->m_uiWidth = uiImageWidth;
	pImage->m_uiHeight = uiImageHeight;
	pImage->m_uiBitDepth = uiImageBytesPerPixel * 8;
	pImage->m_uiBytesPerPixel = uiImageBytesPerPixel;

	if(pImage->m_uiBitDepth <= 24)
		pImage->m_pxFormat = CTextureImage::PX_RGB;
	else 
		pImage->m_pxFormat = CTextureImage::PX_RGBA;

	pImageData = pImageData + (sizeof(IFH_TGAHeader) + uiImageIdent);

	//uncompressed
	if(uiImageType == 2)
	{
		for(uint32 uiSwap = 0; uiSwap < uiImageSize; uiSwap += uiImageBytesPerPixel)
		{
			pImageData[uiSwap] ^= pImageData[uiSwap+2] ^= pImageData[uiSwap] ^= pImageData[uiSwap+2];
		}
	}	

	pImage->SetImageBuffer(pImageData, true);

	return pImage;
#ifdef nothing	

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &glMaxTexDim);					// Get Maximum Texture Size Supported

	int lWidthPixels  = imageWidth;
	int lHeightPixels = imageHeight;

	// Resize Image To Closest Power Of Two
	if (lWidthPixels <= glMaxTexDim) // Is Image Width Less Than Or Equal To Cards Limit
		lWidthPixels = 1 << (int)floor((log((double)lWidthPixels)/log(2.0f)) + 0.5f);
	else  // Otherwise  Set Width To "Max Power Of Two" That The Card Can Handle
		lWidthPixels = glMaxTexDim;

	if (lHeightPixels <= glMaxTexDim) // Is Image Height Greater Than Cards Limit
		lHeightPixels = 1 << (int)floor((log((double)lHeightPixels)/log(2.0f)) + 0.5f);
	else  // Otherwise  Set Height To "Max Power Of Two" That The Card Can Handle
		lHeightPixels = glMaxTexDim;

	// if low quality textures then make them halve the size which saved 4 times the texture space
	if ((m_fHighQualityTextures == FALSE) && (lWidthPixels > 64))
	{
		lWidthPixels /= 2;
		lHeightPixels /= 2;
	}

	// if the size needs to change, the rescale the raw image data
	if ( (lWidthPixels  != (int)imageWidth)	&&
		(lHeightPixels != (int)imageHeight) )
	{
		// allocated the some memory for the new texture
		GLubyte	*pNewImgData = (GLubyte *)malloc(lWidthPixels * lHeightPixels * imageBytesPerPel);

		GLenum format;
		if (imageBytesPerPel == 4)
		{
			format = GL_RGBA;
		}
		else
		{
			format = GL_RGB;
		}

		gluScaleImage(format, imageWidth, imageHeight, GL_UNSIGNED_BYTE, pImgData,
			lWidthPixels, lHeightPixels, GL_UNSIGNED_BYTE, pNewImgData);

		// free the original image data
		free(pImgData);

		// old becomes new..
		pImgData = pNewImgData;

		// update our texture structure
		pglTexture->Width  = lWidthPixels;
		pglTexture->Height = lHeightPixels;
	}

	// Typical Texture Generation Using Data From The TGA loader
	glGenTextures(1, &pglTexture->TextureID);						// Create The Texture

	// generate the texture using the filtering model selected
	(void)GenerateTexture(pglTexture, (BYTE *)pImgData);

	// free the memory allocated
	free(pImgData);

	return TRUE;														// All went well, continue on
#endif
}