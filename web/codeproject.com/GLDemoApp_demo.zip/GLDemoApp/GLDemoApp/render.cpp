//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "render.h"
#include "HighResolutionTimer.h"
#include "FTFont.h"
#include "TextureImage.h"

#include <vector>
#include <assert.h>

// Globals used for rendering.
//
HGLRC g_hGLRC = NULL;
bool g_bFullScreen = false;
bool g_b2dMode = false;

int g_nDesiredWidth = 1024;
int g_nDesiredHeight = 768;

int g_nRenderWidth = g_nDesiredWidth;
int g_nRenderHeight = g_nDesiredHeight;
int g_nBitDepth	= 32;

uint32 g_nSpriteRenderedThisFrame = 0;
uint32 g_nMeshesRendered = 0;
int g_nLastResizeX = 0;
int g_nLastResizeY = 0;

float32 g_fMaxViewDistance = 5000.0f;
float32 g_fMinViewDistance = 0.1f;

int g_nFPS = 0;
uint32 g_nFramesElapsed = 0;

CFTFont g_defaultFont;

float32 g_fOrthoWidth = 1024;
float32 g_fOrthoHeight = 768;
float32 g_fViewAngle = 60.0f;

struct sLoadedSprite
{
	uint32 uiListId;
	uint32 uiRefCount;
	uint32 uiTextureId;

	sLoadedSprite() : uiListId(0), uiRefCount(0), uiTextureId(0) { }
};

std::map<std::string, CTextureImage*> g_loadedTextureCache;
std::map<int, CTextureImage*> g_textureIdToImage;
std::map<int, sLoadedSprite*> g_imageToSprite;

CHighResolutionTimer g_frameTimer;
sRenderCaps g_renderCaps;

void RenderInit()
{
	int nBitDepth = g_nBitDepth;
	int nZBufferDepth = 32;

	RenderSetPixelFormat(nBitDepth, nZBufferDepth);

	RenderCreateRenderingContext();

	std::list<sRenderResolution> lstResolutions;

	RenderQueryResolutions(lstResolutions);	

	//Choose the resolution
	//
	sRenderResolution rResolution;
	rResolution.nWidth = g_nRenderWidth;
	rResolution.nHeight = g_nRenderHeight;
	rResolution.nBitDepth = g_nBitDepth;

	RenderSetResolution(rResolution, g_bFullScreen);

	RenderHandleResize(g_nRenderWidth, g_nRenderHeight);

	g_defaultFont.Init(BuildResourcePath("AGENCYR.TTF"), 18);

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	g_frameTimer.reset();

	glEnable(GL_DEPTH_TEST);

	//////////////////////////////////////////////////////////////////////////
	//
	//
}

void RenderSetPixelFormat(int nBitDepth, int nZBufferDepth)
{
	bool bAccelerated = false;
	int nZBuffer = nZBufferDepth;
	HDC hDC = GetMainHDC();

	PIXELFORMATDESCRIPTOR pfd = 
	{
		sizeof(PIXELFORMATDESCRIPTOR),   // size of this pfd 
		1,                     // version number 
		PFD_DRAW_TO_WINDOW |   // support window 
		PFD_SUPPORT_OPENGL |   // support OpenGL 
		PFD_DOUBLEBUFFER,      // double buffered 
		PFD_TYPE_RGBA,         // RGBA type 
		nBitDepth,             // 24-bit color depth 
		0, 0, 0, 0, 0, 0,      // color bits ignored 
		0,                     // no alpha buffer 
		0,                     // shift bit ignored 
		0,                     // no accumulation buffer 
		0, 0, 0, 0,            // accum bits ignored 
		nZBuffer,              // 32-bit z-buffer 
		0,                     // no stencil buffer 
		0,                     // no auxiliary buffer 
		PFD_MAIN_PLANE,        // main layer 
		0,                     // reserved 
		0, 0, 0                // layer masks ignored 
	};

	int nPixelFormatIdx = ChoosePixelFormat(hDC, &pfd);

	//Set the current pixel format.
	SetPixelFormat(hDC, nPixelFormatIdx, &pfd);

	PIXELFORMATDESCRIPTOR pfdNew;
	DescribePixelFormat(hDC, nPixelFormatIdx, sizeof(PIXELFORMATDESCRIPTOR),&pfdNew);

	DWORD bGenericFormat = (pfdNew.dwFlags & PFD_GENERIC_FORMAT);
	DWORD bGenericAccelerated = (pfdNew.dwFlags & PFD_GENERIC_ACCELERATED);

	if (bGenericFormat && ! bGenericAccelerated )
	{
		// software
		bAccelerated = false;
	}
	else if (bGenericFormat && bGenericAccelerated )
	{
		// hardware - MCD
		bAccelerated = false;
	}
	else if (!bGenericFormat&& ! bGenericAccelerated)
	{
		// hardware - ICD
		bAccelerated = true;
	} 	
}

void RenderQueryResolutions(std::list<sRenderResolution>& lstResolution)
{
	DEVMODE dmGraphics;
	memset(&dmGraphics,0, sizeof(dmGraphics));
	dmGraphics.dmSize = sizeof(DEVMODE);
	//Enum modes on the default device.

	BOOL bModeFound = true;

	for(int i = 0; bModeFound; i++)
	{
		bModeFound = EnumDisplaySettings(NULL, i, &dmGraphics);

		if(bModeFound)
		{
			//test the setting.
			long lResult = ChangeDisplaySettings(&dmGraphics, CDS_TEST);

			if(lResult == DISP_CHANGE_SUCCESSFUL)
			{
				sRenderResolution sRes;

				sRes.nWidth = dmGraphics.dmPelsWidth;
				sRes.nHeight = dmGraphics.dmPelsHeight;
				sRes.nBitDepth = dmGraphics.dmBitsPerPel;

				lstResolution.push_back(sRes);
			}
		}
	}
}

void RenderSetResolution(sRenderResolution& rRes, bool bFullScreen)
{
	g_bFullScreen = bFullScreen;

	if(rRes.nWidth == 0)
	{
		rRes.nWidth = g_nRenderWidth;
		rRes.nHeight = g_nRenderHeight;
		rRes.nBitDepth = g_nBitDepth;
	}

	DEVMODE dmScreenSettings;				
	DWORD	dwExStyle = 0;
	DWORD   dwStyle = 0;

	memset(&dmScreenSettings,0,sizeof(dmScreenSettings));		

	if(bFullScreen)
	{
		dmScreenSettings.dmSize			= sizeof(dmScreenSettings);		
		dmScreenSettings.dmPelsWidth	= rRes.nWidth;			
		dmScreenSettings.dmPelsHeight	= rRes.nHeight;			
		dmScreenSettings.dmBitsPerPel	= rRes.nBitDepth;				
		dmScreenSettings.dmFields = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		INT nResult = ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN);

		dwStyle   = WS_POPUP;						// Windows Style
	}else
	{
		RenderResetDisplay();

		dwStyle   = WS_POPUP | WS_CAPTION;					// Windows Style

		RECT rcClient;
		rcClient.left=0;
		rcClient.top = 0;
		rcClient.bottom = rRes.nHeight;
		rcClient.right = rRes.nWidth;
		AdjustWindowRect(&rcClient, dwStyle, FALSE);

		rRes.nWidth = rcClient.right;
		rRes.nHeight = rcClient.bottom;
	}

	// Some of the following might seem redundant, but it works!
	//
	SetWindowLong(GetMainHWND(), GWL_STYLE, dwStyle);

	SetWindowPos(GetMainHWND(), NULL, 0 , 0, rRes.nWidth, rRes.nHeight, SWP_SHOWWINDOW | SWP_NOZORDER);

	UpdateWindow(GetMainHWND());

	MoveWindow(GetMainHWND(), 0, 0, rRes.nWidth, rRes.nHeight, FALSE);

	ShowWindow(GetMainHWND(), SW_SHOW);

	SetForegroundWindow(GetMainHWND());

	SetFocus(GetMainHWND());

	RenderHandleResize(rRes.nWidth, rRes.nHeight);

	g_nRenderWidth = rRes.nWidth;
	g_nRenderHeight = rRes.nHeight;
	g_nBitDepth = rRes.nBitDepth;
}

bool RenderIsFullScreen()
{
	return g_bFullScreen;
}

void RenderCreateRenderingContext()
{
	g_hGLRC = wglCreateContext(GetMainHDC());
	wglMakeCurrent(GetMainHDC(), g_hGLRC);

	glewInit();
}

void RenderSwapBuffers()
{
	::SwapBuffers(GetMainHDC());

	g_frameTimer.getElapsedTimeInSeconds();

	static float fTime = 0.0f;
	static uint32 nFrames = 0;

	fTime += static_cast<float32>(g_frameTimer.getRealDifference());

	if(fTime > 1.0f)
	{
		g_nFPS = nFrames;//1 / static_cast<float32>(g_frameTimer.getDifference());

		fTime = 0.0f;

		nFrames = 0;
	}

	nFrames++;
	g_nFramesElapsed++;
	g_nSpriteRenderedThisFrame = 0;
	g_nMeshesRendered = 0;
}

void RenderResetDisplay()
{
	ChangeDisplaySettings(NULL, 0);
}

void RenderHandleResize(int nWidth, int nHeight)
{
	if(nHeight == 0)								
	{
		nHeight = 1;							
	}

	RECT rcClient;
	GetClientRect(GetMainHWND(), &rcClient);
	glViewport(rcClient.left, rcClient.top, rcClient.right, rcClient.bottom);					

	g_nLastResizeX = rcClient.right;
	g_nLastResizeY = rcClient.bottom;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();							

	if(g_b2dMode)
	{
		glOrtho(0.0f, g_fOrthoWidth, g_fOrthoHeight, 0.0f, 0.0f, 100.0f);
	}else
	{
		gluPerspective(g_fViewAngle,(GLfloat)nWidth/(GLfloat)nHeight, g_fMinViewDistance, g_fMaxViewDistance);
	}

	glMatrixMode(GL_MODELVIEW);						
	glLoadIdentity();		
}

void RenderIncreaseViewArea(float32 fAmount)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();							

	if(g_b2dMode)
	{
		GLint   viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		//gluOrtho2D(viewport[0],viewport[2], viewport[3], viewport[1]);

		glOrtho(0.0f, g_fOrthoWidth + fAmount, g_fOrthoHeight + fAmount, 0.0f, 0.0f, 100.0f);
	}
	glMatrixMode(GL_MODELVIEW);						
	glLoadIdentity();		
}

void RenderResetViewArea()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();							

	if(g_b2dMode)
	{
		GLint   viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		//gluOrtho2D(viewport[0],viewport[2], viewport[3], viewport[1]);

		glOrtho(0.0f, g_fOrthoWidth, g_fOrthoHeight, 0.0f, 0.0f, 100.0f);
	}
	glMatrixMode(GL_MODELVIEW);						
	glLoadIdentity();		
}

uint32 m_uiEnter2dCount = 0;

void RenderBegin2dMode() 
{
	m_uiEnter2dCount++;		

	if(g_b2dMode)
		return;

	GLint   viewport[4];
	glPushAttrib(GL_TRANSFORM_BIT);
	glGetIntegerv(GL_VIEWPORT, viewport);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0,g_fOrthoWidth, g_fOrthoHeight, 0);
	glDisable(GL_DEPTH_TEST);
	glPopAttrib();
	glPushMatrix();
	glLoadIdentity();
	g_b2dMode = true;
}

void RenderEnd2dMode() 
{
	m_uiEnter2dCount--;

	if(g_b2dMode && m_uiEnter2dCount != 0)
		return;

	glPushAttrib(GL_TRANSFORM_BIT);
	glMatrixMode(GL_PROJECTION);
	glEnable(GL_DEPTH_TEST);
	glPopMatrix();
	glPopAttrib();
	glPopMatrix();
	g_b2dMode = false;
}

void RenderDestroy()
{
	wglDeleteContext(g_hGLRC);

	RenderResetDisplay();
}

void RenderText(CFTFont* pFont, const char* strText, Vector2f& vtPosition, float32 fScale, const sRGBColor& rgbColor)
{
	RenderBegin2dMode();

	GLuint font = pFont->m_uiBase;
	// We Make The Height A Little Bigger.  There Will Be Some Space Between Lines.
	float h = pFont->m_uiFontHeight / .63f;                                                 

	// Here Is Some Code To Split The Text That We Have Been
	// Given Into A Set Of Lines.  
	// This Could Be Made Much Neater By Using
	// A Regular Expression Library Such As The One Available From
	// boost.org (I've Only Done It Out By Hand To Avoid Complicating
	// This Tutorial With Unnecessary Library Dependencies).
	const char *start_line = strText;

	std::vector<std::string> lines;

	const char *c = strText;
	for(;*c;c++) 
	{
		if(*c=='\n') 
		{
			std::string line;

			for(const char *n=start_line;n<c;n++) 
				line.append(1,*n);

			lines.push_back(line);

			start_line=c+1;
		}
	}

	if(start_line) 
	{
		std::string line;

		for(const char *n=start_line;n < c;n++) 
			line.append(1,*n);

		lines.push_back(line);
	}

	glPushAttrib(GL_LIST_BIT | GL_CURRENT_BIT  | GL_ENABLE_BIT | GL_TRANSFORM_BIT); 
	glMatrixMode(GL_MODELVIEW);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	//glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);      

	glListBase(font);

	float modelview_matrix[16];     
	glGetFloatv(GL_MODELVIEW_MATRIX, modelview_matrix);

	// This Is Where The Text Display Actually Happens.
	// For Each Line Of Text We Reset The Modelview Matrix
	// So That The Line's Text Will Start In The Correct Position.
	// Notice That We Need To Reset The Matrix, Rather Than Just Translating
	// Down By h. This Is Because When Each Character Is
	// Drawn It Modifies The Current Matrix So That The Next Character
	// Will Be Drawn Immediately After It.  

	//set the current color to white.
	glColor4f(rgbColor.fRed, rgbColor.fGreen, rgbColor.fBlue, rgbColor.fAlpha);

	for(uint32 i=0;i<lines.size();i++) {
		glPushMatrix();
		glLoadIdentity();
		glTranslatef(vtPosition.x, vtPosition.y - h * i,0);
		glScalef(fScale, fScale, 0.0f);
		glMultMatrixf(modelview_matrix);

		// The Commented Out Raster Position Stuff Can Be Useful If You Need To
		// Know The Length Of The Text That You Are Creating.
		// If You Decide To Use It Make Sure To Also Uncomment The glBitmap Command
		// In make_dlist().
		// glRasterPos2f(0,0);
		glCallLists(static_cast<GLsizei>(lines[i].length()), GL_UNSIGNED_BYTE, lines[i].c_str());
		// float rpos[4];
		// glGetFloatv(GL_CURRENT_RASTER_POSITION ,rpos);
		// float len=x-rpos[0]; (Assuming No Rotations Have Happend)

		glPopMatrix();
	}

	glPopAttrib();          

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);

	RenderEnd2dMode();
}


void RenderText3D(CFTFont* pFont, const char* strText, float32 fScale, const sRGBColor& rgbColor)
{
	glDisable(GL_DEPTH_TEST);

	GLuint font = pFont->m_uiBase;
	// We Make The Height A Little Bigger.  There Will Be Some Space Between Lines.
	float h = pFont->m_uiFontHeight / .63f;                                                 

	// Here Is Some Code To Split The Text That We Have Been
	// Given Into A Set Of Lines.  
	// This Could Be Made Much Neater By Using
	// A Regular Expression Library Such As The One Available From
	// boost.org (I've Only Done It Out By Hand To Avoid Complicating
	// This Tutorial With Unnecessary Library Dependencies).
	const char *start_line = strText;

	std::vector<std::string> lines;

	const char *c = strText;
	for(;*c;c++) 
	{
		if(*c=='\n') 
		{
			std::string line;

			for(const char *n=start_line;n<c;n++) 
				line.append(1,*n);

			lines.push_back(line);

			start_line=c+1;
		}
	}

	if(start_line) 
	{
		std::string line;

		for(const char *n=start_line;n < c;n++) 
			line.append(1,*n);

		lines.push_back(line);
	}

	glPushAttrib(GL_LIST_BIT | GL_CURRENT_BIT  | GL_ENABLE_BIT | GL_TRANSFORM_BIT); 
	glMatrixMode(GL_MODELVIEW);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	//glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);      

	glListBase(font);

	float modelview_matrix[16];     
	glGetFloatv(GL_MODELVIEW_MATRIX, modelview_matrix);

	// This Is Where The Text Display Actually Happens.
	// For Each Line Of Text We Reset The Modelview Matrix
	// So That The Line's Text Will Start In The Correct Position.
	// Notice That We Need To Reset The Matrix, Rather Than Just Translating
	// Down By h. This Is Because When Each Character Is
	// Drawn It Modifies The Current Matrix So That The Next Character
	// Will Be Drawn Immediately After It.  

	//set the current color to white.
	glColor4f(rgbColor.fRed, rgbColor.fGreen, rgbColor.fBlue, rgbColor.fAlpha);

	for(uint32 i=0;i<lines.size();i++) {
		glPushMatrix();
		//glLoadIdentity();
		glTranslatef(0.0f,h*fScale * i, 0.0f);
		glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
		glScalef(fScale, fScale, fScale);
		glCallLists(static_cast<GLsizei>(lines[i].length()), GL_UNSIGNED_BYTE, lines[i].c_str());
		glPopMatrix();
	}

	glPopAttrib();          

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);

}

void RenderStats()
{
	char strStats[512] = {0,};

	float fStartX = 600;
	float fStartY = 30;
	sprintf_s(strStats, 512, "Last RUpdate lrw = %i lrh = %i", g_nLastResizeX, g_nLastResizeY);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY));

	GLint   viewport[4];
	glGetIntegerv(GL_VIEWPORT, viewport);

	sprintf_s(strStats, 512, "Viewport %i %i %i %i", viewport[0],viewport[2], viewport[3], viewport[1]);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 25));

	RECT rcClient;
	GetClientRect(GetMainHWND(), &rcClient);

	sprintf_s(strStats, 512, "Client Rect %i %i %i %i", rcClient.left, rcClient.top, rcClient.right, rcClient.bottom);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 50));

	sprintf_s(strStats, 512, "WH%i %i ", g_nRenderWidth, g_nRenderHeight);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 75));

	sprintf_s(strStats, 512, "FPS = %i", g_nFPS);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 100));

	sprintf_s(strStats, 512, "Frames Elapsed = %i", g_nFramesElapsed);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 125));

	sprintf_s(strStats, 512, "Meshes Rendered This Frame = %i", g_nMeshesRendered);
	RenderText(&g_defaultFont, strStats, Vector2f(fStartX, fStartY + 150));
}

int	RenderGetWidth()
{
	return g_nRenderWidth;
}

int RenderGetHeight()
{
	if(g_bFullScreen)
		return g_nRenderHeight;
	else
		return g_nRenderHeight - 25;
}

float32	RenderGetWidthf()
{
	return static_cast<float32>(g_nRenderWidth);
}

float32 RenderGetHeightf()
{
	if(g_bFullScreen)
		return static_cast<float32>(g_nRenderHeight);
	else
		return static_cast<float32>(g_nRenderHeight - 25);
}


int RenderGetDesiredWidth()
{
	return g_nDesiredWidth;
}

int RenderGetDesiredHeight()
{
	return g_nDesiredHeight;
}

int RenderGetBitDepth()
{
	return g_nBitDepth;
}

float32 RenderGetOrthoWidth()
{
	return g_fOrthoWidth;
}

float32 RenderGetOrthoHeight()
{
	return g_fOrthoHeight;
}

uint32 RenderLoadTexture(const std::string& strFilePath)
{
	CTextureImage* pTexImage = NULL;

	pTexImage = g_loadedTextureCache[strFilePath];

	if(pTexImage == NULL)
	{
		pTexImage = LoadImageFromDisk(strFilePath);

		g_loadedTextureCache[strFilePath] = pTexImage;
	}else if(pTexImage->m_uiHardwareId != 0)
	{
		pTexImage->m_uiReferenceCount++;

		return pTexImage->m_uiHardwareId;
	}

	if(!pTexImage)
		return 0;

	pTexImage->m_uiReferenceCount = 1;

	glEnable(GL_TEXTURE_2D);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	GLuint uiTextureId = 0;
	glGenTextures(1, &uiTextureId);
	glBindTexture(GL_TEXTURE_2D, uiTextureId);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_NEAREST);//GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);//GL_LINEAR);

	bool bEnableAnisotropy = false;
	if(bEnableAnisotropy)
	{
		float32 fMaxAnisotropy = 0.0f;
		glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &fMaxAnisotropy);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, fMaxAnisotropy);
	}

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	int32 nPixelFormat = GL_RGBA;

	if(pTexImage->GetPixelFormat() == CTextureImage::PX_RGB)
		nPixelFormat = GL_RGB;

	glTexImage2D(GL_TEXTURE_2D, 0, nPixelFormat, pTexImage->GetWidth(), pTexImage->GetHeight(), 0, nPixelFormat, GL_UNSIGNED_BYTE, pTexImage->GetImageBuffer());
	gluBuild2DMipmaps(GL_TEXTURE_2D, nPixelFormat, pTexImage->GetWidth(), pTexImage->GetHeight(), nPixelFormat, GL_UNSIGNED_BYTE, pTexImage->GetImageBuffer());

	glDisable(GL_TEXTURE_2D);

	pTexImage->m_uiHardwareId = uiTextureId;

	g_textureIdToImage[uiTextureId] = pTexImage;

	return uiTextureId;
}


void RenderTexture(Vector2f& vPos, int nTextureId, float32 fRot)
{
	CTextureImage* pImage = g_textureIdToImage[nTextureId];

	glEnable(GL_TEXTURE_2D);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, nTextureId);

	bool bNeedsAlpha = pImage->GetPixelFormat() == CTextureImage::PX_RGBA;
	if(bNeedsAlpha)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);      
	}

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glTranslatef(vPos.x, vPos.y, 0.0f);
	glRotatef(fRot, 0.0f, 0.0f, 1.0f);

	float32 fHalfWidth = pImage->GetWidth() / 2.0f;
	float32 fHalfHeight = pImage->GetHeight() / 2.0f;

	glBegin(GL_QUADS);
	glTexCoord2d(0, 0);
	glVertex2f(-fHalfWidth, fHalfHeight);

	glTexCoord2d(0, 1);
	glVertex2f(-fHalfWidth, -fHalfHeight);

	glTexCoord2d(1, 1);		
	glVertex2f(fHalfWidth, -fHalfHeight);

	glTexCoord2d(1, 0);				
	glVertex2f(fHalfWidth, fHalfHeight);		
	glEnd();

	if(bNeedsAlpha)
		glDisable(GL_BLEND);

	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void RenderReleaseTexture(uint32 nTextureId)
{
	CTextureImage* pImage = g_textureIdToImage[nTextureId];

	assert(pImage != NULL);

	if(pImage)
	{
		pImage->m_uiReferenceCount--;

		//If ref count goes to zero, unload the texture.
		//delete from ogl
		if(pImage->m_uiReferenceCount == 0)
		{
			glDeleteTextures(1, &nTextureId);

			g_textureIdToImage[nTextureId] = 0;
			g_loadedTextureCache[pImage->m_strLocation] = 0;

			delete pImage;
		}
	}
}

Vector2f RenderGetScreenCenter()
{
	return Vector2f(RenderGetWidth() / 2.0f, RenderGetHeight() / 2.0f);
}

Vector2f RenderGetScreenOrthoCenter()
{
	return Vector2f(RenderGetOrthoWidth() / 2.0f, RenderGetOrthoHeight() / 2.0f);
}

int32 RenderGetVSyncState()
{
	return (wglGetSwapIntervalEXT) ? (wglGetSwapIntervalEXT()) : 0;
}

void RenderVSync(bool bEnabled)
{
	if (bEnabled)
		wglSwapIntervalEXT(1); 
	else
		wglSwapIntervalEXT(0);
}

CTextureImage* RenderGetImage(uint32 uiId)
{
	return g_textureIdToImage[uiId];
}


void RenderSetupDefaultLight()
{
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	//glEnable(GL_COLOR_MATERIAL);

	// Create light components
	GLfloat globalAmbient[] = { 0.5f, 0.5f, 0.5f, 1.0f };

	GLfloat ambientLight[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat diffuseLight[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat specularLight[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat position[] = { 0.0f, -1.0f, 0.0f, 0.0f };

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globalAmbient);
	glShadeModel(GL_SMOOTH);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);

	glPushMatrix();
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specularLight);
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glPopMatrix();

	glDisable(GL_LIGHTING);
}


void RenderMesh(const sMesh& pMesh)
{	
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_BLEND);

	glColor3f(1.0f, 1.0f, 1.0f);	

	if(pMesh.pfVertices)
	{
		uint32 uiNumberOfComponents = 3;

		bool bHasTexture = false;
		if(pMesh.pMaterials)
		{
			if(pMesh.pMaterials->nTextureIds)
			{
				bHasTexture = true;
				glEnable(GL_TEXTURE_2D);
				glEnableClientState(GL_TEXTURE_COORD_ARRAY);
				glBindTexture(GL_TEXTURE_2D, pMesh.pMaterials->nTextureIds[0]);

				if(pMesh.pfTextureCoordinates[0])	
				{
					if(pMesh.m_nTexCoordVBO)
					{
						glBindBuffer(GL_ARRAY_BUFFER, pMesh.m_nTexCoordVBO);
						glTexCoordPointer(2, GL_FLOAT, 0, NULL);
					}else
					{
						glTexCoordPointer(2, GL_FLOAT, 0, pMesh.pfTextureCoordinates[0]);
					}

				}
			}

			float32 pfWhite[4] = {1.0f,1.0f,1.0f,1.0f};
			float32 pfBlack[4] = {0.0f,0.0f,0.0f,1.0f};

			glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, (float32*)&pMesh.pMaterials->rgbAmbient);
			glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, (float32*)&pMesh.pMaterials->rgbDiffuse);
			glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, (float32*)&pMesh.pMaterials->rgbSpecular);
			glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 100.0f);
			glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, (float32*)&pMesh.pMaterials->rgbEmissive);//(float32*)&(pMesh.pMaterials->rgbEmissive));
		}
		if(pMesh.pfVertices)
		{
			glEnableClientState(GL_VERTEX_ARRAY);
			if(pMesh.m_nVertexVBO)
			{
				glBindBuffer(GL_ARRAY_BUFFER, pMesh.m_nVertexVBO);
				glVertexPointer(3, GL_FLOAT, 0, NULL);
			}else
			{
				glVertexPointer(3, GL_FLOAT, 0, pMesh.pfVertices);
			}
		}

		if(pMesh.pfNormals)
		{
			glEnableClientState(GL_NORMAL_ARRAY);
			if(pMesh.m_nNormalVBO)
			{	
				glBindBuffer(GL_ARRAY_BUFFER, pMesh.m_nNormalVBO);
				glNormalPointer(GL_FLOAT, 0, NULL);
			}
			else
			{
				glNormalPointer(GL_FLOAT, 0, pMesh.pfNormals);
			}
		}	
		glColor3f(1.0f, 1.0f, 1.0f);
		glDrawArrays(GL_TRIANGLES, 0, pMesh.uiNumVertices);

		if(bHasTexture)
		{
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		}
	}

	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);

	if(0)
		glBindBuffer(GL_ARRAY_BUFFER, 0);

	//RenderNormals(pMesh);


	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	g_nMeshesRendered++;
}

void RenderMeshScaled(const sMesh& pMesh, float32 fScale)
{
	glScalef(fScale, fScale, fScale);
	RenderMesh(pMesh);
}


void RenderGroundGrid(float32 fYPos)
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glColor3f(0.0f, 1.0f, 0.0f);
	glBegin(GL_LINES);

	for(float32 fX = -100.0f; fX < 100; fX++)
	{
		glVertex3f(fX, fYPos, -100);
		glVertex3f(fX, fYPos, 100);
	}
	for(float32 fZ = -100.0f; fZ < 100; fZ++)
	{
		glVertex3f(-100, fYPos, fZ);
		glVertex3f(100, fYPos, fZ);
	}
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

void RenderReleaseMesh(sMesh** pMesh)
{
	//Delete the loaded mesh
	//

	RenderReleaseTexture((*pMesh)->pMaterials->nTextureIds[0]);

	delete [] ((*pMesh)->pMaterials->nTextureIds);
	delete (*pMesh)->pMaterials;
	delete [] (*pMesh)->pfColors;
	delete [] (*pMesh)->pfNormals;
	delete [] (*pMesh)->pfTextureCoordinates[0];
	delete [] (*pMesh)->pfTextureCoordinates;
	delete [] (*pMesh)->pfVertices;
	delete [] (*pMesh)->pIdxArray;

	delete (*pMesh);

	(*pMesh) = NULL;

}