//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _INTEGRAL_TYPES_H_
#define _INTEGRAL_TYPES_H_

#include <cfloat>

//Unsigned types.
typedef unsigned __int64 uint64;
typedef unsigned int	uint32;
typedef unsigned short	uint16;
typedef unsigned char	ubyte;
typedef unsigned char	uint8;

//Signed types
typedef __int64 int64;
typedef int				int32;
typedef short			int16;
typedef unsigned char	byte;
typedef char			int8;

//floats
typedef float	float32;
typedef double	float64;

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lp)                        ((int)(short)LOWORD(lp))
#endif

#ifndef GET_Y_LPARAM
#define GET_Y_LPARAM(lp)                        ((int)(short)HIWORD(lp))
#endif

#define MegsToBytes(n) (n * 1024) * 1024
#define KiloToByte(n) (n * 1024)

#include <string>
#include <vector>
#include <map>
#include <list>
#include <memory>
#include <cstdlib>
#include <cstdio>
#include <io.h>
using namespace std;

#endif