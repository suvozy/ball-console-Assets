//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _RENDER_H_
#define _RENDER_H_
#include <list>
#include <windows.h>
#include <gl/glew.h>
#include <gl/wglew.h>
#include "FTFont.h"

class CTextureImage;
class CSceneNode;

//Render Types.
//
struct sRenderResolution
{
	int nWidth;
	int nHeight;
	int nBitDepth;
};

struct sRGBColor
{
	float32 fRed;
	float32 fGreen;
	float32 fBlue;
	float32 fAlpha;

	sRGBColor(float32 fR = 1.0f, float32 fG = 1.0f, float32 fB = 1.0f, float32 fA = 1.0f) : fRed(fR), fGreen(fG), fBlue(fB), fAlpha(fA) {}
};


struct sMaterial
{
	std::string strMaterialName;

	sRGBColor rgbAmbient;
	sRGBColor rgbEmissive;
	sRGBColor rgbDiffuse;
	sRGBColor rgbSpecular;

	uint32* nTextureIds;				//List of texture ids
	uint32 uiTextureCount;		//The number of textures.
};

struct Vertex3f
{
	float32 x,y,z;
};

struct sMesh
{
	std::string strMeshName;

	uint32 uiNumVertices;
	uint32 uiNumNormals;
	uint32 uiNumTexcoords;
	uint32 uiNumColors;

	uint32 uiNumVertexIdx;		//The number of vertices
	uint32 uiNumNormalIdx;
	uint32 uiNumTexCoordIdx;	//The texture coordinate count
	uint32 uiNumColorIdx;

	uint32 uiPolyType;			//The type of polygons the vertices are order in.
	uint32 uiIdxCount;

	float32* pfVertices;				//Pointer to array of verts.
	float32* pfNormals;					//Pointer to array of verts.
	float32** pfTextureCoordinates;		//Pointer to an array of texture coords [coord_set][coord]
	float32* pfColors;				//Color pointer
	uint32* pIdxArray;

	sMaterial* pMaterials;
	uint32	   uiMaterialCount;

	bool	m_bBoundsSet;

	uint32 m_nVertexVBO;
	uint32 m_nNormalVBO;
	uint32 m_nTexCoordVBO;
	uint32 m_nColorVBO;

	sMesh() : 	pMaterials(0), pfVertices(0), pfNormals(0), pfTextureCoordinates(0), pfColors(0), pIdxArray(0),
	m_bBoundsSet(false), m_nNormalVBO(0), m_nVertexVBO(0), m_nTexCoordVBO(0)
	{

	}
};

enum 
{
	RENDER_PATH_FIXED,
	RENDER_PATH_20,
	RENDER_PATH_ARB,
};
struct sRenderCaps
{
	int32 nMaxTextureUnits;
	uint32 nRenderPath;
	bool   bUsePixelShaders;
	bool   bUseVertexShaders;

	uint32 nMaxVertexInstructions;
	uint32 nMaxPixelIntrusctions;

	uint32 nVBOSupported;	
};

extern CFTFont g_defaultFont;
extern float32 g_fMaxViewDistance;
extern float32 g_fMinViewDistance;
extern float32 g_fViewAngle;

#define SPRITE_UNLOADED -1


struct Vector2f 
{
	float x;
	float y;

	Vector2f(float _x, float _y) : x(_x), y(_y) { }
	Vector2f() : x(0.0f), y(0.0f) { }
};
//////////////////////////////////////////////////////////////////////////
//Render interface functions.
//
void RenderInit();
void RenderQueryResolutions(std::list<sRenderResolution>& lstResolution);
void RenderSetResolution(sRenderResolution& rRes, bool bFullScreen);
void RenderSwapBuffers();
bool RenderIsFullScreen();
void RenderHandleResize(int nWidth, int nHeight);
void RenderBegin2dMode();
void RenderEnd2dMode();
void RenderDestroy();


void RenderGroundGrid(float32 fYPos);

float32 RenderGetOrthoWidth();
float32 RenderGetOrthoHeight();

void RenderText(CFTFont* pFont, const char* strText, Vector2f& vtPosition, float32 fScale = 1.0f, const sRGBColor& rgbColor = sRGBColor(1.0f, 1.0f, 1.0f));


uint32 RenderLoadTexture(const std::string& strFilePath);
void RenderTexture(Vector2f& vPos, int nTextureId, float32 fRot);
void RenderReleaseTexture(uint32 nTextureId);

Vector2f RenderGetScreenCenter();
Vector2f RenderGetScreenOrthoCenter();

//////////////////////////////////////////////////////////////////////////
// Query information about current renderer settings.
//
void RenderStats();
int	RenderGetWidth();
int RenderGetHeight();

float32	RenderGetWidthf();
float32 RenderGetHeightf();

int RenderGetDesiredWidth();
int RenderGetDesiredHeight();
int RenderGetBitDepth();

void RenderVSync(bool bEnabled);
int32 RenderGetVSyncState();

void RenderReleaseMesh(sMesh** pMesh);

//////////////////////////////////////////////////////////////////////////
//Used internally, exposed... just in case.
//
void RenderSetPixelFormat(int nBitDepth, int nZBufferDepth);
void RenderCreateRenderingContext();
void RenderResetDisplay();
CTextureImage* RenderGetImage(uint32 uiId);


//////////////////////////////////////////////////////////////////////////
//Mesh support.
//
void RenderMesh(const sMesh& pMesh);

#endif