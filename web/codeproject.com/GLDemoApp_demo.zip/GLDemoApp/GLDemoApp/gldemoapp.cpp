//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#include "stdafx.h"
#include "gldemoapp.h"
#include "demo.h"
#include "render.h"


// Windows callback.
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
ATOM RegisterWindowClass();

//Globals.
//
const std::string g_strWindowClass = "Demo Application";
const std::string g_strWindowTitle = "Demo Application";

HWND g_hWnd = NULL;
HDC  g_hDC = NULL;
int g_nDefaultWindowWidth = 800;
int g_nDefaultWindowHeight = 600;

HINSTANCE g_hAppInstance = NULL;


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	bool bContinue = true;
	MSG	msg;
	int nCmdShow = SW_SHOW;
	ATOM aWinClass = 0;

	aWinClass = RegisterWindowClass();

	if(!aWinClass)
	{
		INT nLastError = GetLastError();
		return 0;
	}

	g_hWnd = CreateWindowEx(0, g_strWindowClass.c_str(), g_strWindowTitle.c_str(), WS_OVERLAPPEDWINDOW, 0, 0, g_nDefaultWindowWidth, g_nDefaultWindowHeight, NULL, NULL, g_hAppInstance, NULL);

	if(!g_hWnd)
		return 0; 

	g_hDC = GetDC(g_hWnd);

	if(!g_hDC) 
		return 0; 


	ShowWindow(g_hWnd, nCmdShow);
	UpdateWindow(g_hWnd);

	InitDemo();

	while(bContinue && RunDemo())
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if(msg.message == WM_QUIT)
			{
				bContinue = false;
			}else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}

	ReleaseDC(g_hWnd, g_hDC);

	DestroyWindow(g_hWnd);

	UnregisterClass(g_strWindowClass.c_str(), g_hAppInstance);

	EndDemo();

	return 0;
}

ATOM RegisterWindowClass()
{
	g_hAppInstance = GetModuleHandle(NULL);

	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= 0;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= g_hAppInstance;
	wcex.hIcon			= LoadIcon(g_hAppInstance, MAKEINTRESOURCE(IDI_WINLOGO));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= g_strWindowClass.c_str();
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_WINLOGO));

	return RegisterClassEx(&wcex);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_SYSCOMMAND :
		{
			switch (wParam)
			{
			case SC_SCREENSAVE:
			case SC_MONITORPOWER:
				return 0;
				break;
			default:
				break;
			}
		}break;

	case WM_CLOSE:
		PostQuitMessage(0);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
		//
		//
		//
	case WM_SHOWWINDOW:
	case WM_ENABLE:
	case WM_MOVE:
	case WM_SIZE:
		//TODO :  Handle Resize
		RenderHandleResize(RenderGetWidth(), RenderGetHeight());		
		return 0;
		break;

	default:
		break;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

HWND GetMainHWND()
{
	return g_hWnd;
}

HDC  GetMainHDC()
{
	return g_hDC;
}


bool ModifyWindowStyle(HWND hWnd, int nStyleOffset,DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwStyle = ::GetWindowLong(hWnd, nStyleOffset);
	DWORD dwNewStyle = (dwStyle & ~dwRemove) | dwAdd;

	if (dwStyle == dwNewStyle)
		return FALSE;

	::SetWindowLong(hWnd, nStyleOffset, dwNewStyle);

	return TRUE;
}
