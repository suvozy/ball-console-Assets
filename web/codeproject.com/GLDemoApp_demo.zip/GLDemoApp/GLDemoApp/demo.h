//Written by Kristian-Angel Carazo free to use and distribute as you see fit.
//Questions, comments, using this for something interesting? rebelcoder@gmail.com
//

#ifndef _DEMO_H_
#define _DEMO_H_

//Called to initialize the application.
//
void InitDemo();

//Called continuously during execution.
//
bool RunDemo();

//Called when the application is about to exit.
//
void EndDemo();

#endif