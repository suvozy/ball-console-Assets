
#include <stdio.h>
#include <windows.h>		
#include "c:\gl.h"			
//#include "c:\glu.h"			
#include "c:\glaux.h"


HGLRC		rc=NULL;	
HDC			dc=NULL;		
HWND		wnd=NULL;		
HINSTANCE	hInstance;		
bool	ready=TRUE;		
	
double x=0;
//global variables
double playerpos=0;
double pcpos=0;
GLuint texture[2];
bool start=true;


GLvoid resize(GLsizei width, GLsizei height);
BOOL startglwindow(char* title, int width, int height, int bits);
GLvoid KillGLWindow(GLvoid);
int DrawGLScene(GLvoid);
int InitGL(GLvoid);
LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void playerno1(float,float,float);
void border(float,float,float);
void Keyboard_Input();
AUX_RGBImageRec *LoadBMP(char *Filename) ;

void readtexture() 
{
AUX_RGBImageRec *TextureImage[2]; 

if (TextureImage[0]=LoadBMP("1.bmp"))
{
glGenTextures(1, &texture[0]); 
glBindTexture(GL_TEXTURE_2D, texture[0]);
glTexImage2D(GL_TEXTURE_2D,
			 0,
			 3,
			 TextureImage[0]->sizeX,
			 TextureImage[0]->sizeY,
			 0,
			 GL_RGB,
			 GL_UNSIGNED_BYTE,
			 TextureImage[0]->data);
glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
}

}

int WINAPI WinMain(	HINSTANCE	hInstance,HINSTANCE	hPrevInstance,LPSTR	lpCmdLine,int nCmdShow)			
{
	MSG		msg;									
	BOOL	done=FALSE;								
    startglwindow("Tutorial no.3 - OpenGl",640,480,32);

	while(!done)									
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	
		{
			if (msg.message==WM_QUIT)				
			{
				done=TRUE;							
			}
			else									
			{
				TranslateMessage(&msg);				
				DispatchMessage(&msg);				
			}
		}
		else										
		{
				Keyboard_Input(); //here we are calling the method
			if (ready)					
			{
					DrawGLScene();					
					SwapBuffers(dc);				
			}
		}
	}
	KillGLWindow();									
	return (msg.wParam);							
}



void playerno1(float posx,float posy,float posz)
{
	glLoadIdentity();

glTranslatef(posx,posy,posz);
glBegin(GL_QUADS); 

glColor3f(0.0f,1.0f,1.0f); //red

glVertex3f( 6.0f, 2.0f, 0.0f); //up right corner

glColor3f(1.0f,1.0f,0.0f); //red

glVertex3f( -6.0f, 2.0f, 0.0f); //up left corner

glColor3f(1.0f,0.0f,1.0f); //red

glVertex3f(-6.0f,0.0f, 0.0f); //down left

glColor3f(0.0f,1.0f,0.0f); //red

glVertex3f( 6.0f,0.0f, 0.0f);//down right

glEnd();
}

void border(float posx,float posy,float posz)
{
	glLoadIdentity();

glTranslatef(posx,posy,posz);
glBegin(GL_QUADS); 

glColor3f(0.0f,0.0f,1.0f); 

glVertex3f( 0.5f, 20.0f, 0.0f); //up right corner

glVertex3f( -1.0f, 20.0f, 0.0f); //up left corner

glVertex3f(-1.0f,-20.0f, 0.0f); //down left

glVertex3f( 0.5f,-20.0f, 0.0f);//down right

glEnd();
}

void ball(float posx,float posy,float posz)
{
glLoadIdentity();

glTranslatef(posx,posy,posz);
glColor3f(1.0f,1.0f,1.0f);
glBegin(GL_QUADS);
glBindTexture(GL_TEXTURE_2D, texture[1]);
glTexCoord2f(0.0f, 1.0f);
glVertex3f( 1.0f, 1.0f, 0.0f); //up right corner

glTexCoord2f(1.0f, 1.0f);
glVertex3f( -1.0f, 1.0f, 0.0f); //up left corner

glTexCoord2f(1.0f, 0.0f);
glVertex3f(-1.0f,-1.0f, 0.0f); //down left

glTexCoord2f(0.0f, 0.0f);
glVertex3f( 1.f,-1.0f, 0.0f);//down right

glEnd();
}


double ballx=0;
double bally=0;
double ballspeed=.05;
bool updown=false;
bool leftright=true;
void calculate_movements()
{
//ball movement
if(start)
{
//these two statements check if the ball have crossed any of the two borders
//and reverse the direction of the ball
if(ballx>20.45)leftright=false;
if(ballx<-20.45)leftright=true;
	
//updown variable is true when the ball is moving up and vice versa

if(!updown)
{
	//if its moving down, this mean that it can hit the player quad
	//we check if it hitted the layer quad here, if it did we revese the 
	//updown bool variable and icrease the ball speed
	if((bally>-16.5 && bally<-13.5)&&(ballx>playerpos-6 && ballx<playerpos+6))
	{
		updown=true;
     	ballspeed+=.01;
	}
	//if the next condition is true, that means that the ball have crossed the
	//limit under the quad, which means that the user have lost
	//we reset the position and speed of the ball here
	else if(bally<-16.5)
	{
		//MessageBox(NULL,"you have lost against your stupid pc","sorry!",NULL);
		bally=0;
		ballx=0;
		ballspeed=.05;
		start=false;
	}
}
else
{//same as above
    if((bally<16.5 && bally>13.5)&&(ballx>pcpos-6 && ballx<pcpos+6))
	{
		updown=false;
	    ballspeed+=.01;
	}
	else if(bally>16.5)
	{
		//MessageBox(NULL,"you have WON against your stupid pc","well done!",NULL);
		bally=0;ballx=0;ballspeed=.05;
				start=false;
	}
}

//the ball will move, when we set it position to a diffrent location
//and thats what happens here, if the ball is moving up, we increase the "y" position of the ball
//same with the ball "x" position
	if(updown)bally+=ballspeed;
	else bally-=ballspeed;
	if(leftright)ballx+=ballspeed;
	else ballx-=ballspeed;
}

//pc movement
// the pc will move according to the ball "x" position
//setting, you can move it slower by setting it to something less 
//than .2
if(start)
{
if(ballx>pcpos) pcpos+=.09;
else pcpos-=.09;
}
}
int DrawGLScene(GLvoid) 
{
calculate_movements();
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
glLoadIdentity(); 

//ball
ball(ballx,bally,-40);

//player
playerno1(playerpos,-16.5,-40.0);


//pc
playerno1(pcpos,14.5,-40.0);

//left border
border(-22.0,0.0,-40);

//right border
border(22.5,0.0,-40);

glEnd();
return TRUE; 
}


GLvoid resize(GLsizei width, GLsizei height)	
{
	glViewport(0,0,width,height);					
	glMatrixMode(GL_PROJECTION);					
	glLoadIdentity();								
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);
	glMatrixMode(GL_MODELVIEW);			
	glLoadIdentity();					
}

int InitGL(GLvoid)				
{	
	readtexture();
	glEnable(GL_TEXTURE_2D); 
	glShadeModel(GL_SMOOTH); 
	glClearColor(0.5f, 1.0f, 1.0f, 0.0f); 
	glEnable(GL_DEPTH_TEST); 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST); 
	return TRUE;
}


GLvoid KillGLWindow(GLvoid)								
{
wglMakeCurrent(NULL,NULL);
wglDeleteContext(rc);
rc=NULL;	
ReleaseDC(wnd,dc);	
dc=NULL;					
DestroyWindow(wnd);
wnd=NULL;										
UnregisterClass("OpenGL",hInstance);
hInstance=NULL;	
}

BOOL startglwindow(char* title, int width, int height, int bits)
{
	
	GLuint		PixelFormat;			
	WNDCLASS	wc;						
	DWORD		dwExStyle;				
	DWORD		dwStyle;				
	RECT		WindowRect;				
	WindowRect.left=(long)0;			
	WindowRect.right=(long)width;		
	WindowRect.top=(long)0;				
	WindowRect.bottom=(long)height;		
			

	hInstance			= GetModuleHandle(NULL);	
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	
	wc.lpfnWndProc		= (WNDPROC) WndProc;					
	wc.cbClsExtra		= 0;									
	wc.cbWndExtra		= 0;									
	wc.hInstance		= hInstance;							
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			
	wc.hbrBackground	= NULL;									
	wc.lpszMenuName		= NULL;									
	wc.lpszClassName	= "OpenGL";								

	RegisterClass(&wc);
	dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;	
	dwStyle=WS_OVERLAPPEDWINDOW;					
	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);	

	wnd=CreateWindowEx(	dwExStyle,"OpenGL",title,dwStyle |	WS_CLIPSIBLINGS |WS_CLIPCHILDREN,0, 0,WindowRect.right-WindowRect.left,
								WindowRect.bottom-WindowRect.top,	
								NULL,								
								NULL,								
								hInstance,							
								NULL);							

	static PIXELFORMATDESCRIPTOR pfd= 
{
sizeof(PIXELFORMATDESCRIPTOR), // Size Of This Pixel Format Descriptor
1, // Version Number
PFD_DRAW_TO_WINDOW | // Format Must Support Window
PFD_SUPPORT_OPENGL | // Format Must Support OpenGL
PFD_DOUBLEBUFFER, // Must Support Double Buffering
PFD_TYPE_RGBA, // Request An RGBA Format
bits, // Select Our Color Depth
0, 0, 0, 0, 0, 0, // Color Bits Ignored
0, // No Alpha Buffer
0, // Shift Bit Ignored
0, // No Accumulation Buffer
0, 0, 0, 0, // Accumulation Bits Ignored
16, // 16Bit Z-Buffer (Depth Buffer) 
0, // No Stencil Buffer
0, // No Auxiliary Buffer
PFD_MAIN_PLANE, // Main Drawing Layer
0, // Reserved
0, 0, 0 // Layer Masks Ignored
};
	
dc=GetDC(wnd);							
PixelFormat=ChoosePixelFormat(dc,&pfd);
SetPixelFormat(dc,PixelFormat,&pfd);	
    rc=wglCreateContext(dc);		
	wglMakeCurrent(dc,rc);					
	ShowWindow(wnd,SW_SHOW);						
	SetForegroundWindow(wnd);						
	SetFocus(wnd);									
	resize(width, height);					
    InitGL();
	return TRUE;									
}





LRESULT CALLBACK WndProc(HWND wnd,UINT	uMsg,WPARAM	wParam,LPARAM lParam)			
{
	switch (uMsg)									
	{
		
		case WM_ACTIVATE:							
		{
			if (!HIWORD(wParam))					
			{
				ready=TRUE;						
			}
			else
			{
				ready=FALSE;						
			}

			return 0;								
		}

		case WM_SYSCOMMAND:							
		{
			switch (wParam)							
			{
				case SC_SCREENSAVE:					
				case SC_MONITORPOWER:				
				return 0;							
			}
			break;									
		}

		case WM_CLOSE:								
		{
			PostQuitMessage(0);						
			return 0;								
		}
		case WM_SIZE:								
		{
			resize(LOWORD(lParam),HIWORD(lParam)); 
			return 0;								
		}
	}

	
	return DefWindowProc(wnd,uMsg,wParam,lParam);
}






void Keyboard_Input()
{
	if((GetKeyState(VK_LEFT) & 0x80))
	{
		if(playerpos>=-15.5)playerpos-=.09;
	}

	if((GetKeyState(VK_RIGHT) & 0x80))
	{
		if(playerpos<=15.5)playerpos+=.09;
	}
	if(GetKeyState('A')& 0x80)
	{
		if(start)start=false;
		else start=true;
	}
}


AUX_RGBImageRec *LoadBMP(char *Filename) 
{
		FILE *File=NULL;

		if (!Filename) 
		{
		return NULL; 
		}

		File=fopen(Filename,"r"); 

		if (File) 
		{
		fclose(File); 
		return auxDIBImageLoad(Filename); 
		}

return NULL; 
}